package com.Veterinary.Animal;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class VeteriAnimalApplicationTests {

	@Test
	void contextLoads() {
	}

}
